var str_wps_name_long = "Quick Secure Setup";
var str_wps_name_short = "QSS";
var wlan_wds = 1;
var our_web_site = "www.tp-link.com";
var wireless_ssid_prefix = "TP-LINK";
var prompt_net_address = "0";
var default_ip = "192.168.0.1";